# Tartarus

Tartarus is a proof-of-concept for my floor-generation method in my port of Persona 3 to the GameBoy.

## Running

The example runs in ```index.html``` so be sure to load it up in your favorite HTML5-compatible browser! You may also want to use the zoom feature, as the GameBoy's screen has a resolution of 160x144 pixels.

## Controls

Use WASD to move